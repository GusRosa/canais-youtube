---
name: radar
description: >
  Pesquisa no YouTube vídeos viralizando em canais pequenos ou novos, por nicho, e devolve
  oportunidades de tema, estruturas de título que estão funcionando e os canais (com link). Também
  checa a concorrência de um tema antes de produzir. Use quando o usuário pedir "radar", "o que está
  viralizando", "ideias de nicho", "temas virais", "oportunidades de vídeo", "canais pequenos
  bombando", "checa a concorrência desse tema" ou /radar.
---

# /radar · Radar de oportunidades no YouTube

Ferramenta em `scripts/radar-youtube/` (Python, sem chave de API). Lê a busca pública do YouTube
(região e idioma do `nichos.json`) e o Google Trends do país.

## Comandos

```bash
cd scripts/radar-youtube
python3 radar.py                          # todos os nichos do nichos.json, último mês
python3 radar.py --periodo semana         # hoje | semana | mes | ano
python3 radar.py --termos "pov you" "old money" --nome pov   # --nome evita sobrescrever o radar do dia
python3 radar.py --checar "why rent got so expensive" "who owns your dentist"
```

Saídas em `saidas/radar/`: `radar-AAAA-MM-DD-<periodo>.md` (relatório) e `.json` (dados).
`historico.json` marca vídeos que já apareceram em radares anteriores.

## Critério (editável em `nichos.json` → `filtros`)

- vídeo com ≥ 500 mil views no período;
- canal com ≤ 300 mil inscritos **ou** criado há ≤ 365 dias;
- ≥ 5 views por inscrito (o vídeo passou da base do canal: sinal de que o algoritmo empurrou);
- canais com mais de 3.000 vídeos ficam de fora (redações e empresas);
- títulos com palavras de `excluir_palavras` ficam de fora (novela, filme, comercial, fanpage).

Nichos e termos de busca ficam em `nichos.json`; adicionar ou trocar conforme o foco.

## Como entregar ao usuário

1. Rodar o radar (3 a 5 min com ~40 termos).
2. Ler o `.md` e **não colar a tabela inteira**. Resumir:
   - 5 a 10 oportunidades mais fortes (views/inscrito alto, canal novo, formato longo), com link do
     canal e do vídeo;
   - temas e estruturas de título que se repetem entre os vencedores;
   - o que está **saturado** (muitos canais novos com o mesmo título, ex.: "Inside the Factory").
3. Para cada ideia que o usuário quiser seguir, rodar `--checar` com o tema e dizer quem já fez e
   quantas views teve, antes de escrever roteiro (fluxo `/video-longo`).
   O `--checar` também lista os **clones do último ano** (mesmo título, inclusive com poucas views).
   Com 3+ clones aparece `⚠ formato clonado`: o tema não é lacuna, mesmo que o topo da busca pareça vazio.
   Conferir os clones na mão, porque palavras soltas geram falso positivo.

## Limites (dizer quando relevante)

- Vê os ~20 primeiros resultados de cada busca, não o YouTube inteiro.
- Views ≠ receita; nicho com CPM baixo pode ter muita view.
- A data de criação é da conta, não do primeiro vídeo.
- Muitos vencedores são canais de conteúdo em série feito com IA: alto risco na política de
  "conteúdo inautêntico". Apontar isso, não recomendar copiar.
