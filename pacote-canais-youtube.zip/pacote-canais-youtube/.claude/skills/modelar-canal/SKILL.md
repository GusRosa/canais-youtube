---
name: modelar-canal
description: >
  Analisa um canal do YouTube (geralmente gringo), ranqueia os vídeos mais vistos, extrai as fórmulas
  de título, checa se o canal já tem dublagem em português e procura no YouTube Brasil quem já postou
  versão traduzida ou adaptada de cada vídeo. Entrega títulos modelados pro Brasil. Use quando o
  usuário mandar link de canal e pedir "analisa esse canal", "modelar canal", "modelar os títulos pro
  Brasil", "tem gente traduzindo esse canal?", "vídeos traduzidos", "copiar esse canal pro BR" ou
  /modelar-canal.
---

# /modelar-canal · Modelar canal gringo pro Brasil

Script em `scripts/radar-youtube/modelar_canal.py` (Python, sem chave de API; usa yt-dlp pra listar
os vídeos e as páginas públicas pra views e faixas de áudio). Reaproveita funções do `radar.py`.

## Passo 1 · Ranking e dublagem

```bash
cd scripts/radar-youtube
python3 modelar_canal.py @Handle            # aceita @handle ou URL do canal
python3 modelar_canal.py @Handle --top 15
```

Gera `saidas/radar/canais/canal-<handle>-<data>.md` e `.json`: inscritos, data de criação, views,
duração e se cada vídeo tem **faixa de áudio PT-BR** (dublagem automática do YouTube).

Ler o `.md` e identificar as **fórmulas de título** dos mais vistos (ex.: "O que acontece com seu
corpo quando…", "Se você tem X, …", "hora a hora", lista + hábito simples).

## Passo 2 · Cópias no Brasil

Escrever um JSON no scratchpad com 1 a 2 termos de busca **em português** para cada um dos ~10 vídeos
do topo (o tema como o brasileiro digitaria, mais a tradução literal do título):

```json
{"DVlhy4-MRtg": ["o que acontece quando você come uma vez por dia", "comer uma vez por dia hora a hora"]}
```

```bash
python3 modelar_canal.py @Handle --copias <scratchpad>/busca.json
```

Usa o `.json` do passo 1 do mesmo dia (não relê o canal) e acrescenta as cópias ao relatório. Cada
resultado vem classificado pela semelhança com o título original:

- **tradução literal** (≥ 0,7): mesmo título traduzido. A busca roda com `hl=en`, então o YouTube
  mostra o título autotraduzido pro inglês e a cópia fica quase igual ao original;
- **adaptação** (0,4 a 0,7): mesmo vídeo com outro ângulo;
- **mesmo tema**: concorrência brasileira no assunto (canais grandes que dominam o tema).

## Passo 3 · Validar os títulos antes de entregar (obrigatório)

Título modelado sem validação vira tradução com outra roupa. Escrever de 12 a 15 candidatos. Cada um
parte de uma **frase que o brasileiro digita** (puxar o autocomplete do tema antes) e traz um
**ângulo que não está no topo** (debate "emagrece ou faz mal?", passo prático, desmentir o que o
mercado vende, recorte de público). Depois validar:

```json
[{"titulo": "Comer uma vez por dia emagrece ou faz mal? O que os estudos mostraram", "busca": "comer uma vez por dia"}]
```

```bash
python3 modelar_canal.py @Handle --validar <scratchpad>/titulos.json
```

`busca` é o termo curto do tema. Para cada título, o script traz:

- **Demanda:** o autocomplete do YouTube Brasil para o termo e a soma de views do topo. Ler as
  sugestões: se elas puxam outro assunto (ex.: "formato da barriga" → gravidez), a demanda é
  **fraca**, mesmo que o script marque média;
- **Novidade:** `já existe` (título quase igual publicado), `parecido` (mesma promessa) ou `novo`,
  com os títulos parecidos e o topo da busca (título exato, termo e só o último ano);
- **Concorrentes fortes:** vídeos com 500 mil+ views no último ano.

Só entregam os títulos com demanda forte ou média de verdade e novidade `novo`. `parecido` só entra
se o ângulo for claramente outro, e dizer qual é o vídeo parecido. Cortar o resto e reescrever até
ter uns 10. Ainda assim é sinal, não garantia: dizer isso.

## Como entregar ao usuário

1. Tabela curta com os 8 mais vistos: views, título original e a fórmula de cada um.
2. **Dublagem:** quantos vídeos já têm áudio PT-BR. Se a maioria tem, avisar que tradução literal
   compete com o próprio original dublado.
3. **Quem já traduz:** canais com tradução literal e as views deles. Comparar com quem adaptou e
   apontar o padrão (em geral a tradução literal não dá view e a adaptação dá). Canais criados no
   mesmo dia ou com nomes paralelos em vários idiomas indicam uma operação de tradução em série.
4. **Concorrente grande** no tema no Brasil (o que mais aparece em "mesmo tema", com views).
5. **Títulos validados no passo 3:** tabela com título, termo buscado, demanda, novidade e o
   concorrente mais próximo. Português natural, sem travessão, sem clichê ("nenhum médico te
   contou", "o único jeito"). Número no título (anos, minutos, dias) precisa de fonte no
   `fontes.md` antes de virar vídeo, e avisar isso. Nunca entregar título que não passou pela
   validação.
6. Pontos de atenção quando couberem: política de desinformação médica (saúde), conteúdo
   inautêntico em série feito com IA, e os limites abaixo.

Pra seguir com uma ideia: `/radar --checar` no tema e depois `/video-longo`.

## Limites (dizer quando relevante)

- Lista só os vídeos longos (aba /videos), não Shorts.
- Cada busca vê os ~15 primeiros resultados: pode haver outras cópias.
- Com `hl=en` o idioma real do vídeo não aparece. "Tradução literal" pode ser outro canal em inglês
  ou espanhol que aparece no Brasil; abrir o link antes de afirmar que é brasileiro.
- Se o yt-dlp falhar ao listar, atualizar com `python3 -m pip install -U yt-dlp`.
