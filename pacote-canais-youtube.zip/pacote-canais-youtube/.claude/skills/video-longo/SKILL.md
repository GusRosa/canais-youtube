---
name: video-longo
description: >
  Produz vídeo narrado estilo documentário (canal faceless) a partir de um
  roteiro ou tema: divide em cenas, narra, busca imagem, escolhe a melhor por cena (juiz visual),
  edita no estilo Dossiê ou Clássico e entrega MP4 Full HD + legenda SRT + descrição, tags e
  capítulos. Faz horizontal (YouTube) e vertical 9:16 com legenda na tela (Reels, Shorts, TikTok).
  Usa o robô em scripts/robo-video. Use quando o usuário pedir "vídeo longo", "vídeo pro youtube",
  "canal dark", "documentário", "robô de vídeo", "shorts narrado", "reels narrado com imagens",
  "transforma esse roteiro em vídeo" ou /video-longo.
---

# /video-longo · Robô de vídeo

Código e detalhes técnicos em
`scripts/robo-video/README.md`.

## Onde salvar

- Canal com pasta própria → `canais/<Nome>/videos/<slug>-<AAAA-MM-DD>/`
- Teste → `saidas/videos/<slug>-<AAAA-MM-DD>/`

Ler o `CLAUDE.md` do canal antes de escrever (modelo em `modelos/CLAUDE-canal.md`). Todo número que for pra narração ou pra tela precisa estar no `fontes.md` do vídeo.

## Formato

- **Horizontal** (padrão): YouTube. Legenda vai no `video.srt`, não na imagem.
- **Vertical** (`"formato": "vertical"` no `cenas.json`): Reels, Shorts, TikTok. A legenda sai
  gravada na imagem, uma linha curta por vez, no terço de baixo e fora da área que o app cobre.
  Roteiro de até 60s (90s no máximo), gancho na primeira frase, cenas de 2 a 5s.
  O mesmo roteiro serve pros dois formatos: trocar só o `formato` e renderizar em outra pasta.
- **Reels de venda** (`"estilo": "reels"`, vertical): vídeo em tela cheia com cor quente (paleta vinho e dourado), transição de zoom/desfoque em cada corte, título em Playfair itálico, legenda
  palavra por palavra (tempo real da ElevenLabs) e cena `"cta": {"palavra": "FRASES"}` como cartão
  final. Usar `"take_max": 3`, `"respiro": 0.15`, `"sfx_transicao"` (whoosh) e `"trilha"`..
- **Alerta** (`"estilo": "alerta"`, vertical): Reels de gatilho/segredo. Preto e vermelho, mídia quase
  sem cor, faixa de AVISO na 1ª cena (com o `destaque` embaixo), vinheta que pulsa como coração, corte
  com glitch, títulos em tarja vermelha, legenda com a palavra falada em bloco vermelho e a palavra do
  `cta` revelada por trás de uma tarja preta. `"marca_dagua": "@perfil"` vira a etiqueta com ponto de
  gravação no topo. Mesmos campos do Reels..
- **Sombra** (`"estilo": "sombra"`, horizontal): canal de poder e sedução masculina. Preto, cor apagada, vinheta, grão;
  títulos em Anton com a última palavra (ou a marcada com `*palavra*`) em vermelho; cartão `"1 · Frase"` vira "PRINCÍPIO 1" e `"Motivo 1 · Frase"` usa o próprio rótulo.
  Foto aparece inteira sobre ela mesma desfocada (busto e retrato vertical não cortam)..
- **Palco 3D** (`"estilo": "palco3d"`, horizontal ou vertical): foto ou vídeo da cena dentro de um
  painel 3D que entra girando e flutua num fundo escuro com partículas; cartão de texto com formas 3D
  girando atrás. Cor do aro e das partículas em `"cor_destaque"` (padrão amarelo `#f2c230`). Bom pra
  vídeo de lista, explicação e tema de tecnologia/dinheiro, onde a moldura dá cara de "apresentação".
  Fica menos imersivo que o Clássico, porque a mídia não ocupa a tela inteira.
- **Iceberg** (`"estilo": "iceberg"`, horizontal): iceberg desenhado em camadas à esquerda, a câmera
  desce a cada camada e a mídia entra num cartão à direita. No topo, `"niveis": [...]` (nome de cada
  camada, da ponta ao fundo); na cena onde a camada começa, `"nivel": n` (as seguintes herdam);
  `"nivel": -1` no fechamento afasta a câmera e mostra o iceberg inteiro com todas as camadas acesas.
  Roteiro do óbvio ao obscuro, com um "Say this" por camada.. No `gerar_cenas.py`, uma função `nivel(n)` ajuda a marcar as camadas.
- **Mapped** (`"estilo": "mapa"`, horizontal): mapa dos EUA, a câmera voa até o estado de cada cena.
  Por cena: `"mapa": {"foco": ["ID"] ou "US", "marcar": ["ID"] ou "TODOS", "pino": {"lon", "lat", "rotulo"}}`
  (cena sem `mapa` herda a anterior). Bom pra tema com estado, cidade ou "every state". Detalhes no README do robô.
- **Stick** (`"estilo": "stick"`, horizontal): bonequinhos desenhados em código, sem imagem de banco.
  Cada cena descreve o quadro em `"boneco"` (fundo, personagens com pose/expressão/acessório, objeto,
  balão, multidão). Bom pra história com personagem ("30 days…", "what happens if…"). Detalhes no README do robô.
- **Whisper** (`"estilo": "whisper"`, vertical): Reels de frase estilo "Whisprs". Ilustração em tela
  cheia com zoom lento, o texto da cena centralizado em letra manuscrita e `"marca_dagua": "@pagina"`
  embaixo. Uma cena por pedaço de frase, com `"imagem_local"`, `"legenda_na_tela": false` e
  `"continuidade": true` (a ElevenLabs recebe o texto vizinho e não quebra a entonação)..
- **Trocar de estilo sem gastar voz:** `node scripts/robo-video/renderizar.mjs <pasta> --estilo nome`
  (ou `--quadros 30,400` pra conferir) usa o `build/props.json` já pronto.
- **Sem legenda na tela** (`"legenda_na_tela": false`): no vertical, a foto cresce e ocupa o centro.
- **Outro idioma:** além do `texto`, pôr `"idioma": "en"` (ou `es`) pra traduzir os rótulos fixos
  do estilo. Versão traduzida de um vídeo pronto: copiar `build/candidatos.json` e `build/midia/`
  pra pasta nova e manter as `escolha`, assim não precisa refazer o juiz.

## Fluxo

0. **Concorrência.** `python3 scripts/radar-youtube/radar.py --checar "<tema>"` (skill `/radar`).
1. **Pesquisa e roteiro.** Pesquisar fontes ANTES de escrever; cada número e data vai pro
   `fontes.md` da pasta (o que não tiver fonte sai ou é narrado sem número, lenda como "conta-se").
   Escrever num `gerar_cenas.py` (lista de cenas em Python que gera `cenas.json` e `roteiro.md`),
   pra poder editar e regerar. Mostrar `roteiro.md` + `fontes.md` e **esperar aprovação** antes de
   gastar crédito de voz. Sem travessão na narração.
   - Estrutura que funciona: abertura com a cena/número mais forte + promessa de 2 a 3 respostas
     (loop aberto) → capítulos com cartão de título e gancho no fim → fechamento que volta à
     abertura. Vídeo de venda: CTA leve no 1º minuto, contextual no meio, direto no fim.
   - **Antes de escrever, escolher o molde pela estrutura do título** em
     `referencias/moldes-roteiro.md` (linha do tempo, dossiê de direitos, reatribuição, lista com
     prova, ponte de autoridade, espelho emocional) e dizer ao usuário qual molde foi usado.
   - Ritmo medido: Adam ~2,5 palavras/s; outras vozes podem ser mais rápidas, medir no primeiro vídeo.
2. **Cenas.** Montar o `cenas.json` na pasta do vídeo (modelo em
   `scripts/robo-video/exemplo/cenas.json`):
   - uma cena por ideia, 1 a 3 frases, 4 a 10 segundos de fala
   - `busca` **em inglês**, concreta e visual ("Volkswagen Beetle 1950s", não "carro do povo").
     Palavra em português que também é nome científico ou de outra coisa traz lixo (ex.: "fusca")
   - `destaque`: 1 a 4 palavras de carimbo/título, ou `null`. Cena sem `busca` vira cartão de texto
   - `tipo`: `video` pra cena de ação, movimento, lugar, multidão; `foto` pra pessoa específica,
     documento, objeto histórico (vídeo de banco raramente tem). `midia_padrao` no topo define o padrão
   - busca de vídeo descreve **ação**: "car driving on highway", não "car"
   - tema histórico: `"fontes": ["wikimedia", "archive"]` na cena (filme de época da Prelinger);
     tema atual: deixar o padrão (Pexels e Pixabay primeiro)
   - usar cartão de texto pra frase de virada, a cada 5 ou 6 cenas, pra quebrar o ritmo
3. **Candidatos.** `node scripts/robo-video/gerar.mjs <pasta> --candidatos` (5 opções por cena, cartela
   1280×720; `"opcoes": 8` no `cenas.json` se o tema for difícil de achar imagem)
4. **Juiz visual.** Juntar as cartelas de 2 em 2 (metade das imagens pra abrir):
   `python3 scripts/robo-video/juntar_cartelas.py <pasta>/build/cartelas <pasta>/build/pares`
   e escolher por cena. Gravar as escolhas num `escolhas.json` ({"cena": escolha}) e as buscas a
   refazer num `rebuscar.json` ({"cena": "nova busca"} ou "FOTO:busca"), e aplicar no `cenas.json`.
   Em vídeo, cada opção mostra 3 momentos (a, b, c): escolher opção **e** momento, conferindo que
   o assunto aparece naquele trecho (a miniatura de um clipe longo engana). Cena de vídeo pede um
   clipe por take: cena de 8s → `["2b", "5a"]`. Critérios:
   combina com a frase narrada, é da época e do lugar certos, não repete a cena anterior, não tem
   marca d'água, rosto de pessoa comum em destaque nem símbolo de ódio. Gravar `"escolha": n`
   (ou `0` pra sem imagem) no `cenas.json`. Se nenhuma servir, trocar a `busca` e repetir o passo 3.
5. **Conferir.** `node scripts/robo-video/gerar.mjs <pasta> --conferir`, depois
   `python3 scripts/robo-video/mosaico.py <pasta>/build/conferir <pasta>/build/mosaico` (24 por imagem)
   e olhar tudo (1 PNG por take: `cena-01a`, `cena-01b`). Depois de trocar escolhas, conferir **só as
   cenas trocadas**: `--conferir --cenas 8,15` (apagar `build/conferir` antes, pra não misturar).
   No Clássico, cena sem mídia vira cartão de texto: se não tiver `destaque`, mostra a narração inteira
   em letra pequena. **Todo cartão precisa de `destaque` curto.** Clipe da Archive costuma mudar de
   cena perto do ponto da prévia: conferir sempre e trocar a escolha se o take não bater. Corrigir texto cortado, carimbo em cima de rosto e imagem esticada.
6. **Render.** `node scripts/robo-video/gerar.mjs <pasta>`. Sai `video.mp4`, `video.srt`,
   `creditos.md`.
7. **Miniatura (horizontal).** `build/thumb/thumb.py` com Pillow: extrair 2 ou 3 quadros dos
   clipes do próprio vídeo (`ffmpeg` do Remotion em `node_modules/@remotion/compositor-darwin-arm64`,
   com `DYLD_LIBRARY_PATH` apontando pra mesma pasta), escurecer o lado do texto, 2 a 4 palavras em
   Impact grande + 1 linha de apoio, salvar `thumbnail.jpg` 1280×720 e conferir em 320×180 (celular).
   Título e miniatura se completam, não repetem palavras.
8. **Publicação.** No vertical, escrever `legenda.md` (texto do post) em vez de `youtube.md`.
   No horizontal, escrever `youtube.md` na pasta com título (3 opções), descrição, capítulos
   (somar a duração das cenas, os tempos estão em `build/props.json`, `frames / 30`), tags e os
   créditos de imagem do `creditos.md` (licença CC exige atribuição). Publicar é manual.
   Vídeo que vende produto: link na **primeira linha da descrição** e no **comentário fixado**
   (com uma pergunta pra puxar comentário); placeholder `[LINK ...]` até o link existir.

## Reels de chamada para o vídeo longo

Versão vertical de ~60s que gera desejo pelo vídeo completo: gancho → a virada do tema → loop
aberto (o erro, o segredo, sem revelar) → "no vídeo completo eu te mostro…" → CTA "comenta PALAVRA
que eu te mando o link". Reaproveitar `build/candidatos.json` e as `escolha` do vídeo longo (mesmas
imagens). Escrever `legenda.md` com a legenda e a mensagem do ManyChat. Palavra na tela sem acento,
e configurar as duas grafias no ManyChat (VIDEO e VÍDEO).

## Trilha

- Fonte segura sem chave: **domínio público na Wikimedia** (ex.: Satie, Chopin, Debussy em gravações
  marcadas Public domain/CC0). Música de origem desconhecida não entra (reivindicação no YouTube).
- Cortar com o ffmpeg do Remotion (`-t <duração> -ar 44100 -ac 2 trilha.wav`; ele não tem filtros de
  fade); o robô já faz entrada de 1,5s e saída de 3s.
- **Medir o volume** antes: comparar RMS da trilha e das falas e escolher `volume_trilha` pra música
  ficar em ~15 a 20% da voz (piano de Satie com voz falada: `0.3`). O "0.12" padrão some com piano.
- Trilha gerada pela ElevenLabs (licença comercial) exige a permissão **Music Generation** na chave.

## Disco

O bundle do Remotion copia `build/midia` pro temporário a cada execução; o robô agora apaga ao sair.
Depois de publicado, pode-se apagar `build/midia`, `build/cartelas`, `build/conferir`, `build/pares`
(recriáveis). **Manter `build/audio`** (narração paga) e as escolhas.

## Voz

Padrão: ElevenLabs com a voz **Adam - Compelling** (`QAmlwgbPtjxpk7u98Qs9`, biblioteca pública),
modelo `eleven_multilingual_v2`. Outra voz por vídeo: `"voz": {"elevenlabs": "<voice_id>"}` no
`cenas.json`. Velocidade: `"velocidade": 1.1` no topo (0.7 a 1.2). Outro idioma: só escrever o
`texto` no idioma, o modelo multilíngue lê na mesma voz; `busca` continua em inglês. Plano Starter: 90 mil caracteres/mês (≈ 9 vídeos de 10 min); conferir saldo antes de
vídeo longo. Sem chave, cai pra OpenAI e depois pra voz do Mac (só teste: avisar o usuário).

Voz clonada de pessoa real só com autorização dessa pessoa.

## Economia de tokens

Imagem é o que mais pesa na conversa. Abrir os pares (2 cartelas por imagem), nunca cartela por cartela;
abrir cartela avulsa só das cenas rebuscadas. Conferir com o mosaico e, nas rodadas seguintes, só as cenas
trocadas. Um vídeo por conversa: o contexto do canal está no CLAUDE.md e no README do cliente.

## Escolha de imagem: armadilhas conhecidas

- Cena atual/abstrata: `"fontes": ["pixabay"]` (Wikimedia e Archive trazem ruído para tema moderno).
- Wikimedia não filtra conteúdo adulto: o robô descarta por palavra no título, mas a revisão da cartela continua obrigatória.
- Archive (Prelinger) falha com frequência no corte: o robô avisa e a cena fica sem o take; trocar a escolha.
- Banco de vídeo não tem marcas reais (Rolls-Royce, FTX): usar foto da Wikimedia/Openverse para o objeto e vídeo genérico para a ação.
