# Moldes de roteiro por estrutura de título

Tirados da leitura de 17 roteiros vencedores em canais pequenos ou novos (out/2026).
 Escolher o molde pela estrutura do título;
os tempos são para vídeo de ~12 min e escalam proporcionalmente.

## Regras que valem pra todos

1. **0:00 a 0:15** · repetir a promessa do título quase literal.
2. **Até 1:30** · mapa da promessa: quantos itens, qual é o pior/maior (guardado pro fim) e qual
   ferramenta prática vem no final. Terminar com motivo pra ficar ("the order matters").
3. **Dizer por que está escondido**, com interesse concreto de alguém (banco, indústria, sistema).
4. **Microestrutura de cada item:** rótulo → prova com nome (lei, estudo, órgão; sempre no
   `fontes.md`) → mecanismo com UMA metáfora do dia a dia → ação exata (frase pronta entre aspas
   quando couber) → ganho concreto → ponte pro próximo.
5. **Re-gancho a cada 2 a 4 min:** "Three down, four to go. And the next one..."
6. **Camada de segurança** quando for saúde ou dinheiro: quem não deve fazer, sinal de alerta, o
   outro lado da lei.
7. **Fechamento volta à abertura** (a pessoa, a frase, a cena) + resolução.
8. **Pedido de comentário específico** (escolha entre duas opções, idade, qual item) e
   **compartilhamento com destinatário** ("send this to one person over 65").
9. Frases curtas. Repetição deliberada da frase-chave ("Let me repeat that.").
10. **Proibido:** estudo, número ou credencial sem fonte; depoimento em 1ª pessoa inventado ("I'm 96").
    Caso ilustrativo é anunciado como tal ("Picture a woman who...").

## A · Linha do tempo · "What Happens to Your X When You Y (Hour/Day/Week by...)"
| Tempo | Bloco |
|---|---|
| 0:00 | Reframe em uma frase ("You aren't starving. You're flipping a switch.") + metáfora-mãe que vai voltar (armazém, cofre) |
| 0:30 | Promessa literal + "Let's start the clock." |
| 1:00 a 9:00 | 5 a 7 blocos por janela de tempo. Cada um: o que você sente → o que acontece por dentro → metáfora. No meio, **o ponto de desistência** ("This is where most people give up") e **a virada** ("around hour 16, people report the lift") |
| 9:00 | O que fazer no fim da linha do tempo (passo 1, 2, 3) |
| 10:00 | Adaptação realista + quem não deve fazer |
| 11:30 | Espelha a 1ª frase. Pergunta de comentário amarrada à linha do tempo ("Did you hit the wall at hour 12 or feel it at 16?") |

Títulos da pesquisa: 4, 7, 8, 9, 10, 14.

## B · Dossiê de direitos · "[Idade]: N Rights [Institution] Hopes You Never Claim"
| Tempo | Bloco |
|---|---|
| 0:00 | Vítima concreta com números (idade, valor, dias) **ou** "a trick of language" da instituição |
| 0:30 | "If you're over X, this can happen to you." Quem é o narrador e por que sabe (sem credencial falsa: "we read the law so you don't have to") |
| 1:00 | Mapa: N itens, o item mais perigoso anunciado, ferramenta de defesa no fim, "the order matters" |
| 1:30 | O que mudou e por quê (a lei, a regra, com nome) + o lado legítimo dela |
| 2:30 a 70% | Itens: cena de dor reconhecível → mito → a regra com nome → por que escondem → **frase exata** → $ economizado. Re-gancho a cada 3 itens |
| 70% a 90% | Camadas de proteção (3 a 5), a primeira grátis e fazível hoje |
| 90% | Volta à vítima do começo, agora com nome, e mostra as 2 ações que teriam evitado tudo |
| fim | "Send this to one person over 65." Inscrição amarrada ao próximo risco ("the next update could affect your account") |

Duração natural: 15 a 25 min. Títulos: 1, 2, 5, 16, 17, 18, 19.

## C · Reatribuição · "X Is NOT [causa óbvia]. It's [causa escondida]"
| Tempo | Bloco |
|---|---|
| 0:00 | Autoteste físico ou cena do sintoma ("Right now, take off one sock") + "it is not X" |
| 0:45 | O que todo mundo faz e por que não funciona ("a diuretic cannot reach tissues") |
| 1:30 | O mecanismo escondido com UMA metáfora ("a conveyor belt that only runs when you move") |
| 4:00 | **Sinais de alerta**: quando NÃO é isso e precisa de médico/advogado hoje |
| 5:30 | 3 padrões que parecem iguais e têm causas diferentes (o espectador se diagnostica) |
| 7:00 | Caso de uma pessoa (real com fonte ou anunciado como ilustrativo) num dia comum, hora a hora |
| 10:00 | 2 autotestes de 30 segundos |
| 11:00 | 3 coisas que pioram + 3 que ajudam |
| 14:00 | Protocolo simples com horários |
| 16:30 | Resultado do caso + 5 coisas pra fazer hoje + frase final que tira a culpa ("Your ankles are not betraying you") |

Em finanças/relacionamento, trocar sintoma por comportamento ("you keep overspending", "you keep
choosing the unavailable one"). Títulos: 17, 20, 21, 22.

## D · Lista com prova · "N [coisas] That [resultado] / Only Buy These N"
| Tempo | Bloco |
|---|---|
| 0:00 | Utilitária: título e item 1 em 5 segundos, sem introdução. Emocional: medo concreto (queda, independência) + "you were told X" + por que escondem |
| item | rótulo → prova → mecanismo → como usar + truque pequeno ("let it sit 10 minutes") → ponte ("wait until you hear the next one") |
| meio | Pedido de inscrição curto, depois de entregar valor |
| fim | Recapitulação em 1 frase por item + aviso de segurança + comentário específico |

Títulos: 3, 12, 13, 23, 24.

## E · Ponte de autoridade · "Neuroscience Confirms: [prática antiga]"
| Tempo | Bloco |
|---|---|
| 0:00 | "What if I told you a single habit..." + as duas autoridades (ciência e tradição) concordam |
| 0:30 | Analogia moderna (o assistente que vira CEO) que leva à história antiga |
| 2:00 | O texto/prática antiga citado literalmente, com a palavra original e o significado |
| 2:30 | O conceito científico com metáfora (ferro no fogo) e o estudo com fonte |
| 7:00 | **Mapa:** cada parte da prática antiga = um mecanismo (o momento "aha") |
| 10:00 | 3 passos práticos com um exemplo pessoal ou de caso real |
| fim | O que fazer se travar + próximo vídeo |

Títulos: 12, 13, 14, 15.

## F · Espelho emocional / cenário · "When A and B Both... (This Happens Next)"
| Tempo | Bloco |
|---|---|
| 0:00 | Descrever o exato momento do espectador em 2ª pessoa ("You stopped reaching out. They stopped reaching out.") |
| 0:30 | "Here's what nobody tells you about that moment" + promessa A, B e "most importantly C" |
| 1:00 | Fases do outro com nome ("relief → curiosity → confusion → fear"), cada uma com o sinal visível |
| 4:00 | Fases suas (dor → energia volta → clareza) |
| 6:00 | Os dois finais possíveis e como distinguir (com sinais concretos) |
| 8:30 | Virada pra autoestima: a pergunta não é o que o outro fará, é quem você vira |
| fim | Frase de fechamento que reenquadra a perda ("what you're losing isn't love, it's the job of keeping someone interested") |

Duração: ~10 min. Títulos: 11, 21.
